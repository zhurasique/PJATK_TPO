/**
 * @author Zhura Serhii S15693
 */
package zad1;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class Futil {
    static String path = "";
    static List<Path> res;

    public static void processDir(String dirName, String resultFileName) {
        path = resultFileName;
        res = new ArrayList<>();
        try {
            if (!new File(resultFileName).exists())
                Files.createFile(Paths.get(resultFileName));
            for (Path ds : Files.newDirectoryStream(Paths.get(dirName))) {
                File tmp = ds.toFile();
                if (tmp.isDirectory())
                    findInDirectory(ds.toString(), res);
                else
                    res.add(ds);
            }
            writeToFile(res, Paths.get(resultFileName));
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void writeToFile(List<Path> list, Path resultFileName) {
        try {
            FileChannel fcout = FileChannel.open(resultFileName, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
            for (Path in : list) {
                FileChannel fcin = FileChannel.open(in, StandardOpenOption.READ);
                ByteBuffer buf = ByteBuffer.allocate((int) fcin.size());

                fcin.read(buf);

                Charset inCharset = Charset.forName("Cp1250"),
                        outCharset = Charset.forName("UTF-8");

                buf.flip();
                CharBuffer cbuf = inCharset.decode(buf);

                buf = outCharset.encode(cbuf);
                fcout.write(buf);
                fcin.close();
            }
            fcout.close();
        } catch (Exception e) {
            System.err.println(e);
            System.exit(1);
        }
    }

    public static void findInDirectory(String dirName, List<Path> res) throws IOException {
        for (Path ds : Files.newDirectoryStream(Paths.get(dirName))) {
            File tmp = ds.toFile();
            if (tmp.isDirectory())
                findInDirectory(ds.toString(), res);
            else
                res.add(ds);
        }
    }
}

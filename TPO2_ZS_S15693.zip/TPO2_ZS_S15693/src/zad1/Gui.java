package zad1;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.NavigableMap;

import static zad1.Service.main_value;

public
    class Gui {
    JLabel jTemp;
    JLabel jMiasto;
    JLabel jMin_temp;
    JLabel jMax_temp;
    JLabel jPressure;
    JLabel jLon;
    JLabel jLat;
    JLabel jHumidity;
    JLabel rateLabel;
    JLabel NBP;
    JLabel textLabel2;
    JLabel jCity;
    JLabel jCountry;
    
    String curr;
    String city;

    public Gui(){
        jTemp = new JLabel();
        jMiasto = new JLabel();
        jMin_temp = new JLabel();
        jMax_temp = new JLabel();
        jPressure = new JLabel();
        jLon = new JLabel();
        jLat = new JLabel();
        jHumidity = new JLabel();
        rateLabel = new JLabel();
        textLabel2 = new JLabel();
        NBP = new JLabel();
        jCity = new JLabel();
        jCountry = new JLabel();
        runGui();
    }

    public void runGui(){
        JFXPanel jfxpanel = new JFXPanel();
        JFrame frame = new JFrame("API GUI");
        frame.setLayout(new GridLayout(0,2));
        Border etched = BorderFactory.createEtchedBorder();
        Border titled1 = BorderFactory.createTitledBorder(etched, "Choose Country and City");
        Border titled2 = BorderFactory.createTitledBorder(etched, "Weather");
        Border titled3 = BorderFactory.createTitledBorder(etched, "Exchange");
        Border titled4 = BorderFactory.createTitledBorder(etched, "NBP");

        JPanel left = new JPanel();
        left.setLayout(new GridLayout(4,0));
        JPanel right = new JPanel();

        JPanel panel1 = new JPanel();
        JPanel panel2 = new JPanel();
        JPanel panel3 = new JPanel();
        JPanel panel4 = new JPanel();

        panel1.setBorder(titled1);
        JTextField jtf1 = new JTextField(10);
        JTextField jtf2 = new JTextField(10);
        jCountry.setText("Kraj - ");
        panel1.add(jCountry); 
        panel1.add(jtf1);
        panel1.add(jCity);
        jCity.setText("Miasto - ");
        panel1.add(jtf2);
        JButton button1 = new JButton("OK");
        panel1.add(button1);
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	if(!jtf1.getText().equals("") && !jtf2.getText().equals("")) {
            		try {
		            	String jtfs1 = jtf1.getText();
		                String jtfs2 = jtf2.getText();
		                Service s = new Service(jtfs1);
		                city = jtf2.getText();
		                String weatherJson = s.getWeather(jtfs2);
		
		                JsonParser jp = new JsonParser();
		                JsonElement je = jp.parse(weatherJson);
		                JsonObject jo = je.getAsJsonObject();
		                JsonObject coord = jo.get("coord").getAsJsonObject();
		                double lon = coord.get("lon").getAsDouble();
		                double lat = coord.get("lat").getAsDouble();
		                String miasto = jo.get("name").getAsString();
		                JsonObject main = jo.get("main").getAsJsonObject();
		                double temp = main.get("temp").getAsDouble();
		                double temp_min = main.get("temp_min").getAsDouble();
		                double temp_max = main.get("temp_max").getAsDouble();
		                double pressure = main.get("pressure").getAsDouble();
		                double humidity = main.get("humidity").getAsDouble();
		
		                jMiasto.setText("Miasto: " + miasto);
		                jLon.setText("Longitude: " + lon + "�");
		                jLat.setText("Latitude: " + lat + "�");
		                jTemp.setText("Temperatura: " + temp + " �C");
		                jMin_temp.setText("Min. temp.: " + temp_min + " �C");
		                jMax_temp.setText("Max. temp.: " + temp_max + " �C");
		                jPressure.setText("Cisnienie: " + pressure + " hPa");
		                jHumidity.setText("Wilgotnosc: " + humidity + " %");
		                Platform.runLater(new Runnable() {
		                    @Override
		                    public void run() {
		                        javaFX(jfxpanel);
		                    }
		                });
            		}catch(Exception ex) {
            			JOptionPane.showMessageDialog(null, "Sprawdz podane danne!");
            		}
	            }else
	            	JOptionPane.showMessageDialog(null, "Podaj najpierw kraj oraz miasto!");
            }   	
           
        });


        panel2.setBorder(titled2);
        panel2.setLayout(new GridLayout(0,3));
        panel2.add(jTemp);
        panel2.add(jMiasto);
        panel2.add(jMin_temp);
        panel2.add(jMax_temp);
        panel2.add(jPressure);
        panel2.add(jLon);
        panel2.add(jLat);
        panel2.add(jHumidity);
        panel4.add(NBP);

        panel3.setBorder(titled3);
        JTextField jtf3 = new JTextField(10);
        panel3.add(textLabel2);
        textLabel2.setText("Podaj kod waluty. (n.p. USD)");
        panel3.add(jtf3);
        JButton button2 = new JButton("OK");  
        panel3.add(button2);
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	if(!jtf1.getText().equals("") && !jtf2.getText().equals("")) {
	                if(!jtf3.getText().equals("")){
	                	try {
		                    Service s = new Service(jtf1.getText());
		                    double tmp = s.getRateFor(jtf3.getText());
		                    curr = jtf3.getText();
		                    rateLabel.setText("1.0 " + jtf3.getText() + " = " + tmp + " " + main_value);
		                    NBP.setText("Kurs NBP zloteggo wobec waluty wybranego kraju" + " : " + s.getNBPRate() + " PLN");
	                	}catch(Exception ex) {
	            			JOptionPane.showMessageDialog(null, "Sprawdz podane danne!");
	            		}
	                }
            	}else
            		JOptionPane.showMessageDialog(null, "Podaj najpierw kraj oraz miasto!");
            }
        });
        panel3.add(rateLabel);

        panel4.setBorder(titled4);

        left.add(panel1);
        left.add(panel2);
        left.add(panel3);
        left.add(panel4);




        frame.add(left);
        frame.add(jfxpanel);
        frame.setSize(1100,800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public void javaFX(JFXPanel jfx){
        Group group = new Group();
        Scene scene = new Scene(group, 500,800);
        jfx.setScene(scene);

        WebView webView = new WebView();

        group.getChildren().add(webView);
        WebEngine webEngine = webView.getEngine();
        webEngine.load("https://en.wikipedia.org/wiki/" + city);
    }
}

/**
 *
 *  @author Zhura Serhii S15693
 *
 */


package zad1;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public
class Service {

    String kraj;
    public String myKey = "&units=metric&appid=5bd1286bb9de5bd64e5faa97a6062d0f";
    public String myPath = "http://api.openweathermap.org/data/2.5/weather?q=";
    public static String main_value;

    public Service(String kraj){
        this.kraj = kraj;
    }

    public String getWeather(String miasto) {
        String s = weather(myPath + miasto + "," + kraj + myKey);
        return s;
    }

    public String weather(String path){
        String str = "" ;
        try {
            URL url = new URL(path);
            URLConnection con = url.openConnection();
            con.setUseCaches(false);
            con.connect();
            InputStreamReader isr = new InputStreamReader(con.getInputStream());
            int tmp;
            while((tmp = isr.read()) != -1){
                str += (char)tmp;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return str;
    }

    public String func(String path){
        String s = "";
        try(FileReader reader = new FileReader(path))
        {
            int c;
            while((c = reader.read()) != -1)
                s += (char)c;
        }
        catch(IOException ex){

            System.out.println(ex.getMessage());
        }
        return s;
    }
    public Double getRateFor(String kod_waluty) {
        String name = func("countryNameToCountryCode.json");
        JsonParser jpp = new JsonParser();
        JsonElement jee = jpp.parse(name);
        JsonArray jarr = jee.getAsJsonArray();
        String result = "";
        for(int i = 0; i < jarr.size(); i++){
            if(jarr.get(i).getAsJsonObject().get("name").getAsString().equals(kraj)){
                result = jarr.get(i).getAsJsonObject().get("code").getAsString();
            }
        }

        String code = func("countryCodeToCurrencyCode.json");
        JsonParser jppp = new JsonParser();
        JsonElement jeee = jppp.parse(code);
        JsonObject jarrr = jeee.getAsJsonObject();
        main_value = jarrr.get(result).getAsString();

        String s = weather("http://api.fixer.io/latest?access_key=8bc48f8894fbb83eee82998d97fa6bd8&base=" + main_value + "&symbols=" + kod_waluty);

        JsonParser jp = new JsonParser();
        JsonElement je = jp.parse(s);
        JsonObject jo = je.getAsJsonObject();
        JsonObject main = jo.get("rates").getAsJsonObject();
        double dd = main.get(kod_waluty).getAsDouble();

        return dd;
    }

    public Double getNBPRate() {
        String sb = weather("http://www.nbp.pl/kursy/xml/a064z180330.xml");
        sb += weather("http://www.nbp.pl/kursy/xml/b013z180328.xml");
        Document doc = Jsoup.parse(sb, "", Parser.xmlParser());
        double res = -1.0;
        for (Element e : doc.select("pozycja")){
            String code = String.valueOf(e.select("kod_waluty").get(0).text());
            if(code.equals(main_value)){
                res = Double.parseDouble(e.select("kurs_sredni").text().replace(',', '.'));
            }
        }
        return res;
    }
}

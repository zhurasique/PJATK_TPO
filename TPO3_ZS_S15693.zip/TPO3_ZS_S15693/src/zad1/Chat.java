package zad1;

import java.awt.event.*;
import javax.swing.*;

public
    class Chat implements ActionListener {

    private JTextField jTextField;
    private JTextArea chat;
    private Client client;

    public Chat(Client c) {
        JPanel panel = new JPanel();
        this.client = c;
        JFrame frame = new JFrame("CHAT");
        jTextField = new JTextField(15);
        jTextField.addActionListener(this);

        chat = new JTextArea(8, 8);
        chat.setLineWrap(true);

        JButton logoutButton = new JButton("LOGOUT");
        logoutButton.setActionCommand("logout");
        logoutButton.addActionListener(this);
        JScrollPane scroll = new JScrollPane(chat);
        panel.setLayout(null);

        logoutButton.setSize(100,30);
        logoutButton.setLocation(0, 330);

        scroll.setSize(400,330);
        scroll.setLocation(0,0);

        jTextField.setSize(300, 30);
        jTextField.setLocation(100,330);

        panel.add(logoutButton);
        panel.add(scroll);
        panel.add(jTextField);

        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.setVisible(true);
        frame.setResizable(false);
    }

    public void addText(String text){
        chat.append(text + "\n");
        chat.setCaretPosition(chat.getDocument().getLength());
        chat.update(chat.getGraphics());
    }
    public void actionPerformed(ActionEvent evt) {
        if ("logout".equals(evt.getActionCommand()))
            System.exit(0);
        if(jTextField.getText().length() > 0)
            this.client.messege(jTextField.getText());
        jTextField.setText("");
    }
}
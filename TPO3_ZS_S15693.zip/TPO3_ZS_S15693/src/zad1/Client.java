/**
 *
 *  @author Serhii Zhura S15693
 *
 */

package zad1;

import java.net.*;
import java.nio.channels.*;

public
    class Client {
    public static void main(String[] args) {
        Login l = new Login();
    }

    private SocketChannel server;
    private String s;

    public Client(String s){
        this.start(s);
    }

    public void start(String s){
        Chat c = new Chat(this);
        this.s = s;

        try{
            SocketChannel socket = SocketChannel.open();
            socket.connect(new InetSocketAddress("localhost", 50512));
            this.server = socket;
        }catch(Exception ex){
            ex.printStackTrace();
        }

        while(true)
            c.addText(CopyPaste.readString(this.server));

    }

    public void messege(String text){
        CopyPaste.writeString( (this.s + ": " +text), this.server);
    }
}
package zad1;

import java.awt.event.*;
import javax.swing.*;

public
    class Login implements ActionListener {

    private JTextField jTextField;
    private JFrame frame;

    public Login() {
        JPanel panel = new JPanel();
        panel.setLayout(null);
        frame = new JFrame ("CHAT LOGIN");
        JLabel jLabel = new JLabel ("NICKNAME:");
        jTextField = new JTextField ();
        jTextField.addActionListener(this);
        JButton jButton = new JButton ("OK");
        jButton.addActionListener(this);

        jTextField.setSize(200,30);
        jTextField.setLocation(80,0);
        jLabel.setSize(70,30);
        jLabel.setLocation(0,0);
        jButton.setSize(70,30);
        jButton.setLocation(290,0);

        panel.add(jLabel);
        panel.add(jTextField);
        panel.add(jButton);

        frame.setSize(400, 80);
        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.setVisible (true);
        frame.setResizable(false);
    }
    public void actionPerformed(ActionEvent evt){
        if(jTextField.getText().length() >= 1){
            new Thread()
            {
                public void run() {
                    new Client(jTextField.getText());
                }
            }.start();
            frame.dispose();
        }else
            JOptionPane.showMessageDialog(null, "MIN. 1 ZNAK!");
    }
}
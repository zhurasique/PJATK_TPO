/**
 *
 *  @author Serhii Zhura S15693
 *
 */

package zad1;


public
    class Main {
    public static void main(String[] args) {
        try{
            new Thread()
            {
                public void run() {
                    new Server();
                }
            }.start();

            new Thread()
            {
                public void run() {
                    new Client("PAN BARTECZKO");
                }
            }.start();

            new Thread()
            {
                public void run() {
                    new Client("MISTER ZHURA");
                }
            }.start();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
}
/**
 *
 *  @author Serhii Zhura S15693
 *
 */

package zad1;

import java.net.*;
import java.util.*;
import java.nio.channels.*;

public
    class Server {
    public static void main(String[] args) {
        Server s = new Server();
    }

    private CopyPaste cp;
    private ServerSocketChannel server;
    private Selector selector;

    public Server(){
        try {
            server = ServerSocketChannel.open();
            server.configureBlocking(false);
            server.socket().bind(new InetSocketAddress("localhost", 50512));

            selector = Selector.open();
            server.register(selector, SelectionKey.OP_ACCEPT);
        } catch(Exception e) {
            e.printStackTrace();
            System.exit(1);
        }

        while(true) {
            try {
                selector.select();
                Set keys = selector.selectedKeys();
                Iterator iter = keys.iterator();

                while(iter.hasNext()) {
                    SelectionKey key = (SelectionKey) iter.next();
                    if (key.isAcceptable()) {
                        SocketChannel cc = server.accept();
                        if (cc != null){
                            cc.configureBlocking(false);
                            cc.register(selector, (SelectionKey.OP_WRITE | SelectionKey.OP_READ) );
                        }
                    }

                    if (key.isReadable()) {
                        SocketChannel sc = (SocketChannel) key.channel();
                        String result_string = cp.readString(sc);
                        this.message(result_string);
                    }
                }
            } catch(Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void message(String s) {
        try {
            selector.select();
            Set keys = selector.selectedKeys();
            Iterator iter = keys.iterator();

            while (iter.hasNext()) {
                SelectionKey key = (SelectionKey) iter.next();
                if (key.isWritable()) {
                    SocketChannel sc = (SocketChannel) key.channel();
                    cp.writeString(s, sc);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
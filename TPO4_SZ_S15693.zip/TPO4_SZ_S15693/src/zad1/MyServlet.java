package zad1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlet
 */
@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {

    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlet() {
        super();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            response.setContentType("text/html");
            response.setCharacterEncoding("utf-8");
            PrintWriter pw = response.getWriter();

            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:8839/BooksDB?verifyServerCertificate=false&useSSL=true", "root", "root");

            String query = "";
            String text = request.getParameter("text");
            String type = request.getParameter("type");
            pw.println(getStartPage());

            if (text == null || type == null) {
                query = "SELECT * FROM Book";
            } else if (type.equals("1")) {
                query += "SELECT * FROM Book WHERE Name LIKE \'" + text + "%\'";
            } else if (type.equals("2")) {
                query = "SELECT b.* FROM Author a" + " JOIN BookAuthor ba on ba.IdAuthor = a.Id"
                        + " JOIN Book b on ba.IdBook = b.Id" + " WHERE a.Author LIKE \'" + text + "%\'"
                        + " ORDER BY b.Name";
            }

            Statement st = conn.createStatement();
            ResultSet rsBook = st.executeQuery(query);
            ResultSet rsAuthor;
            String name;
            String authors;
            int id;

            while (rsBook.next()) {
                authors = "";
                id = Integer.parseInt(rsBook.getString("Id"));
                name = rsBook.getString("Name");
                query = "SELECT a.* FROM Author a" + " JOIN BookAuthor ba on ba.IdAuthor = a.Id" + " WHERE ba.IdBook = "
                        + id + " ORDER BY a.Author";
                st = conn.createStatement();
                rsAuthor = st.executeQuery(query);

                if (rsAuthor.next()) {
                    authors += rsAuthor.getString("Author");
                    while (rsAuthor.next())
                        authors += ", " + rsAuthor.getString("Author");
                }

                pw.println(getFormattedRow(id, name, authors));
            }
            pw.println(getEndPage());

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String getFormattedRow(int id, String name, String authors) {
        return "<tr><td>" + id + "</td><td>" + name + "</td><td>" + authors + "</td></tr>";
    }

    private String getStartPage() {
        return "<form action=\"./MyServlet\" method=\"get\"><select name=\"type\"> "
                + "<option value=\"1\" selected>by Name</option>" + "<option value=\"2\">by Author</option>"
                + "</select>" + "<input type=\"text\" name=\"text\" /><input type=\"submit\" />"
                + "</form><table style=\"text-align: left;\"><tr><th style=\"min-width: 50px;"
                + "\">Id</th><th style=\"min-width: 150px;"
                + "\">Name</th><th style=\"min-width: 150px;\">Author</th></tr>";
    }

    private String getEndPage() {
        return "</table>";
    }

}

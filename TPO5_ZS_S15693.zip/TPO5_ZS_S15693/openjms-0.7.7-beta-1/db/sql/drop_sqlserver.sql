DROP TABLE system_data;
DROP TABLE seeds;
DROP TABLE destinations;
DROP TABLE messages;
DROP TABLE message_handles;
DROP TABLE consumers;
DROP TABLE users;

package zad2;

import javax.jms.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;

public class Chat extends JFrame implements Runnable {
    JTextArea message;
    JTextField jTextField;
    JTextArea chat;
    Destination destination;
    Session session;

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (UnsupportedLookAndFeelException | ClassNotFoundException | InstantiationException
                | IllegalAccessException e) {
            JOptionPane.showMessageDialog(null, e);
        }

        EventQueue.invokeLater(() -> {
            try {
                String nickname = "defaultNick";
                if (args.length != 0)
                    nickname = args[0];

                Chat client = new Chat(nickname);
                client.setVisible(true);

                Thread thread = new Thread(client);
                thread.start();

            } catch (Exception e) {
                System.out.print("cos z serverem =)");
                exit(1);
            }
        });
    }

    public Chat(String nickname) throws NamingException, JMSException {
        JPanel panel = new JPanel();
        JFrame frame = new JFrame("CHAT");
        jTextField = new JTextField(15);

        chat = new JTextArea(8, 8);
        chat.setLineWrap(true);

        JScrollPane scroll = new JScrollPane(chat);
        panel.setLayout(null);

        scroll.setSize(400,330);
        scroll.setLocation(0,0);

        jTextField.setSize(300, 30);
        jTextField.setLocation(100,330);

        panel.add(scroll);
        panel.add(jTextField);

        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(panel);
        frame.setVisible(true);
        frame.setResizable(false);

        JButton button = new JButton("send");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                MessageProducer sender;
                try {
                    if (message.getText().length() == 0)
                        throw new Exception("min. 1 znak!");
                    sender = session.createProducer(destination);
                    TextMessage message = session.createTextMessage(nickname + ": " + Chat.this.message.getText());
                    sender.send(message);
                    Chat.this.message.setText("");
                } catch (Exception e) {
                    System.out.print("Cos z serwerem.");
                }

            }
        });
        button.setSize(100,30);
        button.setLocation(0, 330);
        jTextField.add(button);

    }

    // PONIZHEJ COPYPASTE - BARTECZKO

    @Override
    public void run() {
        try {
            Hashtable<String, String> properties = new Hashtable<String, String>();
            properties.put(Context.INITIAL_CONTEXT_FACTORY, "org.exolab.jms.jndi.InitialContextFactory");
            properties.put(Context.PROVIDER_URL, "tcp://localhost:3035/");

            Context context = new InitialContext(properties);

            ConnectionFactory connectionFactory = (ConnectionFactory) context.lookup("ConnectionFactory");

            Connection connection = connectionFactory.createConnection();
            session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
            destination = (Destination) context.lookup("topic1");

            MessageConsumer receiver = session.createConsumer(destination);
            connection.start();

            TextMessage message;

            while ((message = (TextMessage) receiver.receive()) != null) {
                chat.append(message.getText() + "\n");
            }
        } catch (Exception e) {
            System.out.print("cos z serverem =)");
            exit(1);
        }
    }

    private static void exit(int i) {
        System.exit(i);
    }
}

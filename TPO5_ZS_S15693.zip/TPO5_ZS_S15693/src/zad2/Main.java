package zad2;

public
    class Main {

    public static void main(String[] args) {
        Chat.main(new String[]{"PAN BARTECZKO"});
        Chat.main(new String[]{"PAN ZHURA"});
    }
}

